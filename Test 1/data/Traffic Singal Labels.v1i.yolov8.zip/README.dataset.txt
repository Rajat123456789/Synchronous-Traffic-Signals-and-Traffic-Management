# Traffic Singal Labels > 2024-04-09 9:18pm
https://universe.roboflow.com/traffic-monitoring-ignhx/traffic-singal-labels

Provided by a Roboflow user
License: MIT

